# MYTHOS + Lounge — hunter operating system (shareable bundle)

A file-system-as-brain operating system for an LLM security-research agent, plus
**Lounge**, a multi-agent "two-seats-at-one-table" coordination layer. Built for
authorized, program-scoped bug-bounty work. This bundle is the **framework only** —
all live hunt data, findings, credentials, and personal identifiers have been removed
or scrubbed (see `REDACTION_NOTES.md`).

## What this is

The core idea: an LLM agent's chat context is volatile and gets cleared. So the agent's
real memory, discipline, and state live on **disk**, and a set of **hooks + doctrine +
skills** force a repeatable loop:

```
GROUND (read disk) -> PROBE (run something real) -> ANALYZE -> PERSIST (write disk) -> VALIDATE
```

It is deliberately opinionated: probes beat assertions, no "theory-closure," every
load-bearing negative gets a positive control, and the agent never ends a work item
before writing state back to disk.

## Layout

```
engine/
  CLAUDE.core.md        the always-loaded core contract (the agent's constitution)
  MYTHOS_CLAUDE_OS.txt  the full manual / long-form doctrine
  kimi-mythos/          scripts + hooks (session_start, precompact, journal, checkpoint,
                        resume, newtarget, mtarget, sync_mirrors, guards) + STATE templates/
  claude-mythos/        the same hook/script set wired for a second agent runtime
  grok-rules/           CRITICAL_HUNTER.md + HUNTER_V5.md (the "brain" / hunting contract)
  skills/               25 modular skills (recon, critical-hunt, chain, report-draft, ...)
  hooks-config/         settings.json showing how the hooks are wired into the harness
lounge/                 the multi-agent layer: seatlib.py, conductor.py, protocol, install.sh
shared/                 generic toolkit the doctrine references:
                        probelib.py (HTTP probe lib w/ self-test), capture_v3.py (MITM capture),
                        probe.sh, bypass_matrix.sh, TRAPS.md, TOOLS.md, source-first methodology
```

## The three pillars

1. **Doctrine** (`engine/CLAUDE.core.md`, `grok-rules/*.md`, `MYTHOS_CLAUDE_OS.txt`) —
   the rules the agent reloads every session. Hunter "operating law" (ground-truth-first,
   entropy-before-brute, kill-criteria, server-sentence-same-pass), the 5 tendons, and
   protocols P01–P14.

2. **Hooks + scripts** (`engine/*/`) — shell/python that fire on harness events
   (SessionStart, PreToolUse, PreCompact, Stop) to auto-journal every tool call, checkpoint
   before context loss, nudge persistence, and re-ground after compaction. This is what makes
   the loop survive token-death.

3. **Lounge** (`lounge/`) — when two agents work one target, `seatlib.py` + `conductor.py`
   give them a shared board (claim a cell, post a hypothesis, reflect, take the next lead)
   so they don't collide or both stop after one failure. One takes `next`; the other is the
   critic + variant hunter.

## Start here

- Read `SETUP_GUIDE.md` to install hooks and wire it to Claude Code (or another agent CLI).
- Read `engine/CLAUDE.core.md` top-to-bottom — it is the whole philosophy in ~150 lines.
- Then `lounge/README.md` + `lounge/LOUNGE_PROTOCOL.md` for the multi-agent layer.

## Scope / ethics

This system is built for **authorized, program-scoped** security research (bug bounty / VRP).
Every piece of doctrine assumes a signed-off scope file and a human who submits. Keep it that way.
